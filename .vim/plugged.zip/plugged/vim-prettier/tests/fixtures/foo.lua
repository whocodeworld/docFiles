  function deepcopy(orig)
          local orig_type = type(orig)
     local copy
     
    return copy
end
