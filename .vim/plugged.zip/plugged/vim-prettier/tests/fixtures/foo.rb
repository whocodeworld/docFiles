for i in [1, 2, 3] do
  p i
end
