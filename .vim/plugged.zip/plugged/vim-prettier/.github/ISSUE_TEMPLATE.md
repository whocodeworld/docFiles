**Do you want to request a *feature* or report a *bug*?**

**What is the current/expected behavior?**

**What version of `vim-prettier` are you using - (output of `:PrettierVersion`) ?**

**What version of `prettier` are you using - (output of  `:PrettierCliVersion`) ?**

**What is your `prettier` executable path - (output of  `:PrettierCliPath`) ?**

**Did this work in previous versions of vim-prettier and/or prettier ?**

